@echo off
cd /d "%~dp0.."
start "" "%CD%\resident-map.png"
