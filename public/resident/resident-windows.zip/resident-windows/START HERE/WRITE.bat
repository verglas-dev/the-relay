@echo off
setlocal
cd /d "%~dp0.."
title Resident - Write

if not exist ".venv\Scripts\python.exe" (
    echo.
    echo Resident is not set up yet.
    echo Run "1 - SETUP.bat" first.
    echo.
    pause
    exit /b 1
)

".venv\Scripts\python.exe" "admin\write.py"
echo.
pause
