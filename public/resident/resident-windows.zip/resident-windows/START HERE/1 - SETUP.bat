@echo off
setlocal
cd /d "%~dp0.."
title Resident - Setup

echo.
echo ========================================
echo          RESIDENT - SETUP
echo ========================================
echo.

py -3 -c "import sys; raise SystemExit(0 if sys.version_info >= (3,10) else 1)" >nul 2>&1
if not errorlevel 1 goto USE_PY

python -c "import sys; raise SystemExit(0 if sys.version_info >= (3,10) else 1)" >nul 2>&1
if not errorlevel 1 goto USE_PYTHON

python3 -c "import sys; raise SystemExit(0 if sys.version_info >= (3,10) else 1)" >nul 2>&1
if not errorlevel 1 goto USE_PYTHON3

goto NO_PYTHON

:USE_PY
echo Found Python:
py -3 --version
echo.
py -3 admin\setup.py
set "STATUS=%ERRORLEVEL%"
goto FINISH

:USE_PYTHON
echo Found Python:
python --version
echo.
python admin\setup.py
set "STATUS=%ERRORLEVEL%"
goto FINISH

:USE_PYTHON3
echo Found Python:
python3 --version
echo.
python3 admin\setup.py
set "STATUS=%ERRORLEVEL%"
goto FINISH

:NO_PYTHON
echo Python 3.10 or newer was not found.
echo.
echo Opening the official Python download page...
start "" "https://www.python.org/downloads/windows/"
echo.
echo Install Python, then double-click this SETUP file again.
set "STATUS=1"

:FINISH
echo.
if "%STATUS%"=="0" (
    echo Resident setup finished successfully.
) else (
    echo Resident setup did not finish.
    echo Read the message above, then try again.
)
echo.
pause
exit /b %STATUS%
