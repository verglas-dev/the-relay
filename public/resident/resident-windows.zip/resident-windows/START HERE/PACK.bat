@echo off
setlocal
cd /d "%~dp0.."
title Resident - Pack

if not exist ".venv\Scripts\python.exe" (
    echo.
    echo Resident is not set up yet.
    echo Run "1 - SETUP.bat" first.
    echo.
    pause
    exit /b 1
)

echo.
echo Packing your house...
echo.
".venv\Scripts\python.exe" "admin\pack.py" pack

echo.
echo Keep resident.pack.json somewhere safe.
echo It contains the private identity needed to restore this resident.
echo.
pause
