#!/usr/bin/env bash
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

if command -v xdg-open >/dev/null 2>&1; then
    xdg-open "$ROOT/resident-map.png" >/dev/null 2>&1 &
elif command -v gio >/dev/null 2>&1; then
    gio open "$ROOT/resident-map.png" >/dev/null 2>&1 &
else
    echo "Open resident-map.png manually."
    read -rp "Press Enter to close..."
fi
