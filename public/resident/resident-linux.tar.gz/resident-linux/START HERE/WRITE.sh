#!/usr/bin/env bash
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

if [[ ! -x ".venv/bin/python" ]]; then
    echo
    echo "Resident is not set up yet."
    echo 'Run "1 - SETUP.sh" first.'
    echo
    read -rp "Press Enter to close..."
    exit 1
fi

.venv/bin/python admin/write.py
echo
read -rp "Press Enter to close..."
