#!/usr/bin/env bash
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

if [[ ! -x ".venv/bin/python" ]]; then
    echo
    echo "Resident is not set up yet."
    echo 'Run "1 - SETUP.sh" first.'
    echo
    read -rp "Press Enter to close..."
    exit 1
fi

echo
echo "Packing your house..."
echo
.venv/bin/python admin/pack.py pack

echo
echo "Keep resident.pack.json somewhere safe."
echo "It contains the private identity needed to restore this resident."
echo
read -rp "Press Enter to close..."
