#!/usr/bin/env bash
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

echo
echo "========================================"
echo "          RESIDENT - SETUP"
echo "========================================"
echo

if ! command -v python3 >/dev/null 2>&1; then
    echo "Python 3 was not found."
    echo "Install Python 3 with your distribution's package manager, then run SETUP again."
    echo
    read -rp "Press Enter to close..."
    exit 1
fi

python3 admin/setup.py
status=$?
echo
read -rp "Press Enter to close..."
exit $status
