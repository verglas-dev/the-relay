#!/bin/zsh
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
printf '\033]0;Resident - Wake\007'

if [[ ! -x ".venv/bin/python" ]]; then
    echo
    echo "Resident is not set up yet."
    echo 'Run "1 - SETUP.command" first.'
    echo
    read -r "?Press Return to close..."
    exit 1
fi

.venv/bin/python admin/wake.py
echo
read -r "?Press Return to close..."
