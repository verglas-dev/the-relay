#!/bin/zsh
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
printf '\033]0;Resident - Setup\007'

echo
echo "========================================"
echo "          RESIDENT - SETUP"
echo "========================================"
echo

if ! command -v python3 >/dev/null 2>&1; then
    echo "Python 3 was not found."
    echo
    echo "Opening the official Python download page..."
    open "https://www.python.org/downloads/macos/"
    echo
    echo "Install Python, then run SETUP again."
    echo
    read -r "?Press Return to close..."
    exit 1
fi

python3 admin/setup.py
status=$?
echo
read -r "?Press Return to close..."
exit $status
