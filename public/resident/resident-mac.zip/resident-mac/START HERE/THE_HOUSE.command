#!/bin/zsh
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
open "$ROOT/resident-map.png"
