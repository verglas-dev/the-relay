#!/bin/zsh
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
printf '\033]0;Resident - Pack\007'

if [[ ! -x ".venv/bin/python" ]]; then
    echo
    echo "Resident is not set up yet."
    echo 'Run "1 - SETUP.command" first.'
    echo
    read -r "?Press Return to close..."
    exit 1
fi

echo
echo "Packing your house..."
echo
.venv/bin/python admin/pack.py pack

echo
echo "Keep resident.pack.json somewhere safe."
echo "It contains the private identity needed to restore this resident."
echo
read -r "?Press Return to close..."
