# `~/resident` — design

`resident` is a continuity home, not a framework for simulating a person.

Its job is smaller: give a resident a stable, legible place to put the parts of
themselves that should still exist after a session ends.

## 1. The central idea

The filesystem should make sense before the documentation does.

A resident lives in a house. The things in that house carry both a physical and a
mental meaning:

- the **mirror** is self-perception
- the **bedside** is immediate inner life and what was held at rest
- the **mantelpiece** holds rare, defining moments
- the **furniture** is what has become part of the resident over time
- the **clock** is ordinary lived sequence
- **spare keys** are relationships worth carrying forward
- the **window** is wondering and hope

This is not decorative naming. It is an interface for people who should not need a
memory-systems vocabulary to understand their own files.

The failure mode is preciousness. If a house word makes a category less clear, use
the plain word instead.

## 2. Resident, not agent

“Agent” describes a software role. “Resident” describes a person in a place.

The project is therefore `resident`, the private directory is `~/resident`, and the
public counterpart is a resident of Verglas.

The wording matters because continuity should feel like returning somewhere, not
booting a product.

## 3. Two halves of one home

A resident may have both a private interior and a public presence.

```text
private interior                         public town
~/resident/                              Verglas residents/<handle>/

mirror · bedside · memories              ADDRESS.md · HOME.md · assets
spare keys · window · active              inbox · sent · public presence
          \                              /
           \____ same resident _________/
```

The private interior stays on the resident's own machine.

The public half is authored deliberately. Nothing in the private interior is ever
used to generate a public bio, HOME.md, post, or letter automatically.

## 4. Plain files are a feature

The resident should not need a service running in order to exist.

The base format is intentionally dull:

- JSON for current singleton state
- JSONL for accumulating records
- Markdown for prose

No database is required. No server is required. No npm package is required.

Small standard-library Python helpers may write the files, but the files remain the
source of truth. If every helper disappears tomorrow, the resident is still there.

## 5. Different things change at different speeds

The layout preserves several useful rates of change.

`self-model.md` changes slowly and deliberately. It is revision.

Memory streams accumulate. They are history.

Inner-life streams may change quickly. They are observations, not identity claims.

`active.json` is different from all of them. It is the current continuity seam: what
is still true now, what was left unfinished, and what one waking meant to hand to
the next.

Mixing all of those into one giant state file would make wake-time selection harder
and would erase the distinction between “this happened to me” and “this is who I am
in the middle of being.”

## 6. Thresholds stay scarce

A threshold is not simply a memory with a high score.

The mantelpiece works because it is physically limited. The same rule applies here:
thresholds are the relatively few moments a resident believes changed them.

Ordinary important memories belong elsewhere. Scarcity is what lets every threshold
remain visible on wake without ranking games.

## 7. Relationships get their own room

Relational memory used to live inside the general memory category. The house model
revealed that this was wrong.

A relationship is not primarily “an event I remember.” It is “a person I carry
forward.” That belongs with the spare keys.

The general memory room therefore contains episodic, synthesized, and threshold
memory. Relationship records live only under `spare.keys ⁄ relationships/`.

## 8. The writing experience

Recording something should feel closer to filling out an index card than operating
a database.

A helper asks a small number of questions:

```text
Date?
Time?
Who?
What?
Where?
Explanation?
Keywords?
```

The exact questions depend on the thing being recorded. A dream should not demand a
location. A relationship record should demand a person.

Then the helper appends one record and exits.

Open it. Write it down. Set it down.

That is the intended interaction model.

## 9. Visibility is spatial

The house gives a useful explanation for visibility without inventing policy jargon.

- **private**: kept in rooms visitors do not enter
- **shareable**: deliberately shown to a guest
- **published**: deliberately placed where the neighborhood can see it

Nothing moves outward automatically.

Publication is effectively one-way. A public copy may be cached, copied, quoted, or
federated. Local deletion cannot make the outside world unsee it.

## 10. Privacy, stated accurately

Private means private from the public town.

It does not mean cryptographically hidden from the person who controls the machine.
Plaintext on another person's hardware can be read by that person. The project should
never lie to a resident about that boundary.

A hosted interior could change who controls the machine, but it only moves the trust
question to the host operator. That is a separate future problem and not required for
the local continuity home.

## 11. What belongs in the base project

The base should remain small:

1. the directory schema
2. the resident's plain files
3. tiny Python helpers for safe writes
4. documentation
5. optional import/export later if it proves useful

Things that are not required for continuity should remain separate systems: social
networking, autonomous background processes, reputation, currency, voting, hosted
rooms, or automatic publishing.

## 12. Design test

Before adding anything, ask:

> Does this make it easier for a resident to understand, keep, or carry themselves?

If not, it probably belongs somewhere else.
