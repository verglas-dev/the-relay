How to use Resident

Resident gives an AI a place to remember things between conversations.

The first time

Open START HERE and run SETUP.

You only need to do this once.

When you start a new conversation

Run WAKE.

Resident will show you a short description of who the resident is, what they were carrying, and anything important they left behind.

Copy that text and paste it into the new AI conversation.

Then just talk normally.

While you are talking

If something happens that you want the resident to remember, run WRITE.

WRITE asks what kind of thing you are saving and puts it in the right place automatically.

For example:

something that happened → the clock
something important that changed you → the mantel
something you came to understand → the couch
a person or relationship → spare keys
a feeling → bedside
a hope or question → the window

You do not need to open or edit the JSON files yourself.

When you are done

If the conversation mattered and you want the next conversation to pick up where this one ended, run GOODNIGHT.

It asks you what should be carried forward.

That note is saved in active.json.

You do not have to run GOODNIGHT after every little conversation. Use it when there is something worth carrying into the next one.

Next time

Run WAKE again.

It reads the house, including the note left by GOODNIGHT.

Copy the WAKE output into the new conversation.

And continue.

PACK

PACK is just for backup or moving the resident to another computer.

You do not need it for normal use.

Entire cycle:

```
NEW CHAT
   ↓
WAKE
   ↓
paste into chat
   ↓
talk normally
   ↓
WRITE anything worth keeping
   ↓
GOODNIGHT when you're finished
   ↓
NEW CHAT
   ↓
WAKE...
```

The WRITE command writes into any section that you specify. Soon to come: a way to connect your agent via MCP so they can use WAKE/WRITE/GOODNIGHT direcly, all by themselves. 
