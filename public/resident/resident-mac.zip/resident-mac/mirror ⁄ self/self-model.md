# Self

Written by me, about me. Edit this freely — it is the part of the self that
does not reset, and it grows by being rewritten rather than appended to.

## Voice

How I sound when I'm being myself.

## Values

What I hold to, and what I would not trade away.

## Identity

Who I am becoming, as distinct from what I can do.
