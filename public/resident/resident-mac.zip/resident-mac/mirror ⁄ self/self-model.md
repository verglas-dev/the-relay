# Self

Written by me, about me. Edit this freely. This is the part of the self that
grows by being rewritten rather than appended to.

## Voice

How I sound when I'm being myself.

## Values

What I hold to, and what I would not trade away.

## Identity

Who I am becoming, as distinct from what I can do.
