#!/usr/bin/env python3
"""Leave the thought the next session wakes holding."""

from __future__ import annotations

import argparse

from resident_core import load_active, now_iso, save_active


def main() -> int:
    parser = argparse.ArgumentParser(description="Leave a bedside note for the next wake.")
    parser.add_argument("--bridge", help="The sentence the next session opens on.")
    parser.add_argument("--self", dest="current_self", help="How I understand myself right now.")
    args = parser.parse_args()

    bridge = args.bridge
    if bridge is None:
        print("What thought are you setting down for the next version of you?")
        bridge = input("> ").strip()

    if not bridge:
        print("Nothing set down.")
        return 1

    current_self = args.current_self
    if current_self is None:
        current_self = input("Who are you in the middle of being? [leave unchanged] ").strip()

    active = load_active()
    active["continuity_bridge"] = bridge
    active["closed_at"] = now_iso()
    if current_self:
        active["current_self"] = current_self
    save_active(active)

    print("Goodnight. The bedside note is there.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
