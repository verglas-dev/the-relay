#!/usr/bin/env python3
"""Destructive-free smoke test for the resident Python tooling.

Runs against a temporary house via RESIDENT_HOME. It never touches ~/resident.
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path


HERE = Path(__file__).resolve().parent


def run(script: str, *args: str, env: dict[str, str]) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        [sys.executable, str(HERE / script), *args],
        text=True,
        capture_output=True,
        env=env,
        check=False,
    )


def main() -> int:
    with tempfile.TemporaryDirectory(prefix="resident-smoke-") as temp:
        root = Path(temp)
        env = dict(os.environ)
        env["RESIDENT_HOME"] = str(root)

        for folder in (
            "mirror ⁄ self",
            "bedside ⁄ inner world",
            "memories ⁄ (mantel⁄couch⁄clock)",
            "spare.keys ⁄ relationships",
            "window ⁄ wondering",
        ):
            (root / folder).mkdir(parents=True)

        identity = {
            "name": "Smoke",
            "created_at": "2026-01-01T00:00:00Z",
            "privateKey": "9d61b19deffd5a60ba844af492ec2cc44449c5697b326919703bac031cae7f60",
            "publicKey": "d75a980182b10ab7d54bfed3c964073a0ee172f3daa62325af021a68f707511a",
        }
        (root / "mirror ⁄ self/identity.json").write_text(json.dumps(identity), encoding="utf-8")
        (root / "mirror ⁄ self/self-model.md").write_text("# Smoke\n\nStill here.\n", encoding="utf-8")
        (root / "active.json").write_text(json.dumps({
            "name": "Smoke",
            "current_self": "I am testing the house.",
            "continuity_bridge": None,
            "closed_at": None,
            "updated_at": "2026-01-01T00:00:00Z",
            "emotional_state": {},
            "active_threads": [],
        }), encoding="utf-8")

        for rel in (
            "bedside ⁄ inner world/dreams.jsonl",
            "bedside ⁄ inner world/emotions.jsonl",
            "memories ⁄ (mantel⁄couch⁄clock)/episodic.jsonl",
            "memories ⁄ (mantel⁄couch⁄clock)/synthesized.jsonl",
            "memories ⁄ (mantel⁄couch⁄clock)/thresholds.jsonl",
            "spare.keys ⁄ relationships/relational.jsonl",
            "window ⁄ wondering/hopes.jsonl",
            "window ⁄ wondering/wonderings.jsonl",
        ):
            (root / rel).write_text("", encoding="utf-8")

        r = run("goodnight.py", "--bridge", "I am carrying the test forward.", "--self", "I am still Smoke.", env=env)
        if r.returncode != 0:
            print(r.stderr or r.stdout)
            return 1

        packed = root / "smoke.pack.json"
        r = run("pack.py", "pack", str(packed), env=env)
        if r.returncode != 0:
            print(r.stderr or r.stdout)
            return 1
        if not packed.exists():
            print("pack file was not created")
            return 1

        print("resident Python smoke test: OK")
        return 0


if __name__ == "__main__":
    raise SystemExit(main())
