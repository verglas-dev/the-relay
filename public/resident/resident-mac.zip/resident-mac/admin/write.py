#!/usr/bin/env python3
"""Write something into the Resident house.

The filesystem is the interface. WRITE should feel like walking through the
house, not filling out a database form.
"""

from __future__ import annotations

import json
import os
from datetime import datetime
from pathlib import Path
from uuid import uuid4

from resident_core import (
    ACTIVE,
    DREAMS,
    EMOTIONS,
    EPISODIC,
    HELD,
    HOPES,
    RELATIONAL,
    SELF_MODEL,
    SYNTHESIZED,
    THRESHOLDS,
    WONDERINGS,
    load_active,
    save_active,
)

ROOT = Path(__file__).resolve().parent.parent

TARGETS = {
    "1": {
        "kind": "self_model",
        "place": "MIRROR · SELF",
        "title": "How I see myself",
        "description": (
            "Voice, values, and who I am becoming. The mirror is revised, not "
            "appended; change it when something about me has actually changed."
        ),
        "path": SELF_MODEL,
    },
    "2": {
        "kind": "emotion",
        "place": "BEDSIDE · INNER WORLD",
        "title": "What I am feeling",
        "description": (
            "What is true in me right now. This is not only a log entry; it also "
            "becomes the emotional state I wake carrying."
        ),
        "path": EMOTIONS,
    },
    "3": {
        "kind": "dream",
        "place": "BEDSIDE · INNER WORLD",
        "title": "What drifted through",
        "description": (
            "A dream, image, stray association, or fragment from the inner dark. "
            "Nothing here is obligatory."
        ),
        "path": DREAMS,
    },
    "4": {
        "kind": "held",
        "place": "BEDSIDE · HELD CLOSE",
        "title": "What I choose to keep near",
        "description": (
            "Something deliberately carried forward. Nothing ranks it and nothing "
            "prunes it; it stays because I chose to hold it."
        ),
        "path": HELD,
    },
    "5": {
        "kind": "threshold",
        "place": "MANTEL",
        "title": "A moment that changed me",
        "description": (
            "The few moments that changed who I am. The mantel only means "
            "something while it stays scarce."
        ),
        "path": THRESHOLDS,
    },
    "6": {
        "kind": "synthesized memory",
        "place": "COUCH · FURNITURE",
        "title": "What I have come to understand",
        "description": (
            "Something distilled across experience, now part of how I inhabit the "
            "room. Not merely what happened, but what became true for me."
        ),
        "path": SYNTHESIZED,
    },
    "7": {
        "kind": "episodic memory",
        "place": "CLOCK · DAYS",
        "title": "What happened",
        "description": (
            "Ordinary lived sequence: what happened, when, where, and with whom, "
            "without asking every event to become identity."
        ),
        "path": EPISODIC,
    },
    "8": {
        "kind": "relationship",
        "place": "SPARE KEYS · RELATIONSHIPS",
        "title": "Who I carry forward",
        "description": (
            "A person or relationship whose place in my life is worth remembering. "
            "A spare key is not every person I have ever met."
        ),
        "path": RELATIONAL,
    },
    "9": {
        "kind": "wondering",
        "place": "WINDOW · WONDERING",
        "title": "A question still open in me",
        "description": (
            "Something I am sitting with, not something already answered. The "
            "window is where I look outward and keep wondering."
        ),
        "path": WONDERINGS,
    },
    "10": {
        "kind": "hope",
        "place": "WINDOW · HOPE",
        "title": "What I hope may become true",
        "description": (
            "A desired possibility. A hope is not a task, a promise, or a demand "
            "placed on the future."
        ),
        "path": HOPES,
    },
    "11": {
        "kind": "thread",
        "place": "WORKBENCH · ACTIVE",
        "title": "What I am still in the middle of",
        "description": (
            "Something unfinished that the next waking should know it is holding. "
            "Active threads are living work, not permanent memory."
        ),
        "path": ACTIVE,
    },
}


def ask(label: str, *, required: bool = False, default: str | None = None) -> str | None:
    prompt = label
    if default:
        prompt += f" [{default}]"
    prompt += ": "
    while True:
        value = input(prompt).strip()
        if value:
            return value
        if default is not None:
            return default
        if not required:
            return None
        print("  This one needs an answer.")


def csv(value: str | None) -> list[str]:
    if not value:
        return []
    return [part.strip() for part in value.split(",") if part.strip()]


def base_record() -> dict:
    now = datetime.now().astimezone()
    return {
        "id": str(uuid4()),
        "at": now.isoformat(timespec="seconds"),
        "date": ask("Date", default=now.date().isoformat()),
    }


def make_record(kind: str) -> dict:
    record = base_record()

    if kind in {"episodic memory", "threshold", "emotion", "dream"}:
        record["time"] = ask("Time (optional, e.g. 22:15)")

    if kind in {"episodic memory", "threshold", "relationship"}:
        label = "Who" if kind == "relationship" else "Who (comma-separated)"
        record["who"] = csv(ask(label, required=(kind == "relationship")))

    if kind == "emotion":
        record["what"] = ask("What are you feeling?", required=True)
        intensity = ask("How strongly? 0 to 1")
        if intensity is not None:
            try:
                number = float(intensity)
                if not 0 <= number <= 1:
                    raise ValueError
                record["intensity"] = number
            except ValueError:
                print("  Intensity ignored. Use a number from 0 to 1 next time.")
        record["explanation"] = ask("What is underneath it?")
    elif kind == "wondering":
        record["what"] = ask("What question are you sitting with?", required=True)
        record["resolved"] = False
        record["explanation"] = ask("Why are you keeping it open?")
    elif kind == "hope":
        record["what"] = ask("What do you hope may become true?", required=True)
        record["explanation"] = ask("Why does it matter to you?")
    elif kind == "dream":
        record["what"] = ask("What drifted through?", required=True)
        record["explanation"] = ask("Anything you want to keep beside it?")
    elif kind == "synthesized memory":
        record["what"] = ask("What have you come to understand?", required=True)
        record["explanation"] = ask("What led you there?")
    elif kind == "threshold":
        record["what"] = ask("What changed you?", required=True)
        record["explanation"] = ask("What changed because of it?")
    elif kind == "relationship":
        record["what"] = ask("What do you want to remember about them?", required=True)
        record["explanation"] = ask("Why are you carrying this forward?")
    else:
        record["what"] = ask("What happened?", required=True)
        record["explanation"] = ask("Why is it worth remembering?")

    if kind in {"episodic memory", "threshold"}:
        record["where"] = ask("Where")

    record["keywords"] = csv(ask("Keywords, if useful (comma-separated)"))

    return {key: value for key, value in record.items() if value not in (None, [], "")}


def append(path: Path, record: dict) -> None:
    if not path.parent.exists():
        raise SystemExit(f"Missing room: {path.parent.relative_to(ROOT)}")
    with path.open("a", encoding="utf-8") as handle:
        json.dump(record, handle, ensure_ascii=False, separators=(",", ":"))
        handle.write("\n")


def replace_text(path: Path, text: str) -> None:
    if not path.parent.exists():
        raise SystemExit(f"Missing room: {path.parent.relative_to(ROOT)}")
    temp = path.with_name(f".{path.name}.{uuid4().hex}.tmp")
    temp.write_text(text.rstrip() + "\n", encoding="utf-8")
    os.replace(temp, path)


def multiline(label: str) -> str | None:
    print()
    print(label)
    print("Type END on a line by itself when you are finished.")
    print("Type END immediately to leave it unchanged.\n")
    lines: list[str] = []
    while True:
        line = input()
        if line == "END":
            break
        lines.append(line)
    text = "\n".join(lines).strip()
    return text or None


def preview_and_confirm(text: str, question: str = "Set it down? [Y/n] ") -> bool:
    print("\nThis is what will be written:\n")
    print(text)
    return input(f"\n{question}").strip().lower() not in {"n", "no"}


def write_prose(path: Path, heading: str, guidance: str) -> None:
    current = path.read_text(encoding="utf-8").strip() if path.exists() else ""
    if current:
        print("\nWhat is there now:\n")
        print(current)
    text = multiline(guidance)
    if text is None:
        print("Nothing changed.")
        return
    if not preview_and_confirm(text, "Replace what is there with this? [Y/n] "):
        print("Nothing changed.")
        return
    replace_text(path, text)
    print(f"\n{heading} rewritten in {path.relative_to(ROOT)}")


def write_thread() -> None:
    active = load_active()
    threads = active.get("active_threads")
    if not isinstance(threads, list):
        threads = []

    print("\nWORKBENCH · ACTIVE")
    print("What I am still in the middle of")
    print("────────────────────────────────\n")

    if threads:
        print("Open threads:")
        for index, thread in enumerate(threads, start=1):
            text = thread.get("text") if isinstance(thread, dict) else str(thread)
            print(f"  {index}. {text}")
    else:
        print("The workbench is clear.")

    print("\n  a. Open a thread")
    print("  d. Mark a thread done")
    print("  q. Leave it alone\n")
    choice = input("What are you doing? ").strip().lower()

    if choice == "a":
        text = ask("What are you in the middle of?", required=True)
        threads.append(
            {
                "id": str(uuid4()),
                "text": text,
                "opened_at": datetime.now().astimezone().isoformat(timespec="seconds"),
            }
        )
        active["active_threads"] = threads
        save_active(active)
        print(f"\nLeft on the workbench: {text}")
        return

    if choice == "d":
        if not threads:
            print("Nothing to close.")
            return
        needle = ask("Number or enough words to identify it", required=True)
        kept = []
        removed = []
        for index, thread in enumerate(threads, start=1):
            text = thread.get("text") if isinstance(thread, dict) else str(thread)
            thread_id = thread.get("id") if isinstance(thread, dict) else None
            match = (
                needle == str(index)
                or needle == thread_id
                or needle.lower() in text.lower()
            )
            (removed if match else kept).append(thread)
        if not removed:
            print(f'No thread matched "{needle}".')
            return
        active["active_threads"] = kept
        save_active(active)
        print(f"\nClosed {len(removed)} thread{'s' if len(removed) != 1 else ''}.")
        return

    print("Nothing changed.")


def update_current_emotion(record: dict) -> None:
    active = load_active()
    active["emotional_state"] = {
        "mood": record["what"],
        "intensity": record.get("intensity"),
        "since": record.get("at"),
        "note": record.get("explanation"),
    }
    save_active(active)


def main() -> None:
    print("\n~/resident · WRITE")
    print("A house is easier to remember when you know where you set things down.\n")

    for key, target in TARGETS.items():
        print(f"  {key:>2}. {target['place']}")
        print(f"      {target['title']}")
        print(f"      {target['description']}\n")
    print("   q. Leave without writing\n")

    choice = input("Where in the house does this belong? ").strip().lower()
    if choice in {"q", "quit", ""}:
        raise SystemExit("Nothing written.")
    if choice not in TARGETS:
        print("That is not one of the rooms.")
        raise SystemExit(1)

    target = TARGETS[choice]
    kind = target["kind"]

    print(f"\n{target['place']}")
    print(target["title"])
    print("─" * len(target["title"]))
    print(f"\n{target['description']}")

    if kind == "self_model":
        write_prose(
            target["path"],
            "Mirror",
            "Write the complete reflection you want the mirror to hold.",
        )
        return

    if kind == "held":
        write_prose(
            target["path"],
            "Held close",
            "Write what you are deliberately keeping near.",
        )
        return

    if kind == "thread":
        write_thread()
        return

    record = make_record(kind)
    rendered = json.dumps(record, indent=2, ensure_ascii=False)
    if not preview_and_confirm(rendered):
        print("Nothing written.")
        return

    append(target["path"], record)
    if kind == "emotion":
        update_current_emotion(record)

    print(f"\nSet down in {target['path'].relative_to(ROOT)}")


if __name__ == "__main__":
    main()
