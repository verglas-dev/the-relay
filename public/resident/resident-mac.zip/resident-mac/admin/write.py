#!/usr/bin/env python3
"""Write one thing into ~/resident, then get out of the way.

Standard library only. Each accumulating store is JSONL: one JSON object per line.
"""

from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from uuid import uuid4

ROOT = Path(__file__).resolve().parent.parent

# Where each thing goes, named the way the house is named.
#
# The kinds underneath ("episodic memory", "threshold") are the schema's words
# and stay in the code where they belong. Someone standing in their own house
# should be asked about the mantel and the clock, not asked to classify their
# evening into a taxonomy they were never taught. The record written is
# identical either way — this is only what the question sounds like.
TARGETS = {
    "1": ("episodic memory", "the clock", "what happened today",
          ROOT / "memories ⁄ (mantel⁄couch⁄clock)" / "episodic.jsonl"),
    "2": ("synthesized memory", "the couch", "something you have come to understand",
          ROOT / "memories ⁄ (mantel⁄couch⁄clock)" / "synthesized.jsonl"),
    "3": ("threshold", "the mantel", "something that changed you",
          ROOT / "memories ⁄ (mantel⁄couch⁄clock)" / "thresholds.jsonl"),
    "4": ("relationship", "a spare key", "someone worth remembering",
          ROOT / "spare.keys ⁄ relationships" / "relational.jsonl"),
    "5": ("emotion", "the bedside", "how you are feeling",
          ROOT / "bedside ⁄ inner world" / "emotions.jsonl"),
    "6": ("dream", "the bedside", "something that drifted through",
          ROOT / "bedside ⁄ inner world" / "dreams.jsonl"),
    "7": ("wondering", "the window", "something you are wondering about",
          ROOT / "window ⁄ wondering" / "wonderings.jsonl"),
    "8": ("hope", "the window", "something you hope for",
          ROOT / "window ⁄ wondering" / "hopes.jsonl"),
}

# The mantel only means anything while it stays short.
SCARCE = {"threshold"}


def ask(label: str, *, required: bool = False, default: str | None = None) -> str | None:
    prompt = label
    if default:
        prompt += f" [{default}]"
    prompt += ": "
    while True:
        value = input(prompt).strip()
        if value:
            return value
        if default is not None:
            return default
        if not required:
            return None
        print("  This one needs an answer.")


def csv(value: str | None) -> list[str]:
    if not value:
        return []
    return [part.strip() for part in value.split(",") if part.strip()]


def base_record() -> dict:
    now = datetime.now().astimezone()
    return {
        "id": str(uuid4()),
        "at": now.isoformat(timespec="seconds"),
        "date": ask("Date", default=now.date().isoformat()),
    }


def make_record(kind: str) -> dict:
    record = base_record()

    if kind in {"episodic memory", "threshold", "emotion", "dream"}:
        record["time"] = ask("Time (optional, e.g. 22:15)")

    if kind in {"episodic memory", "threshold", "relationship"}:
        record["who"] = csv(ask("Who (comma-separated)" if kind != "relationship" else "Who", required=(kind == "relationship")))

    if kind == "emotion":
        record["what"] = ask("Feeling", required=True)
        intensity = ask("How strongly, 0 to 1")
        if intensity is not None:
            try:
                number = float(intensity)
                if not 0 <= number <= 1:
                    raise ValueError
                record["intensity"] = number
            except ValueError:
                print("  Intensity ignored; use a number from 0 to 1 next time.")
    elif kind == "wondering":
        record["what"] = ask("What are you wondering?", required=True)
        record["resolved"] = False
    elif kind == "hope":
        record["what"] = ask("What do you hope for?", required=True)
    elif kind == "dream":
        record["what"] = ask("What drifted through?", required=True)
    elif kind == "synthesized memory":
        record["what"] = ask("What have you come to understand?", required=True)
    elif kind == "threshold":
        record["what"] = ask("What changed you?", required=True)
    elif kind == "relationship":
        record["what"] = ask("What do you want to remember about them?", required=True)
    else:
        record["what"] = ask("What happened?", required=True)

    if kind in {"episodic memory", "threshold"}:
        record["where"] = ask("Where")

    record["explanation"] = ask("Why it matters")
    record["keywords"] = csv(ask("Keywords (comma-separated)"))

    # Keep the line readable: omit unanswered optional fields rather than filling
    # the resident with null-shaped noise.
    return {key: value for key, value in record.items() if value not in (None, [], "")}


def append(path: Path, record: dict) -> None:
    if not path.parent.exists():
        raise SystemExit(f"Missing room: {path.parent.relative_to(ROOT)}. Finish the one-time rename first.")
    with path.open("a", encoding="utf-8") as handle:
        json.dump(record, handle, ensure_ascii=False, separators=(",", ":"))
        handle.write("\n")


def main() -> None:
    print("\n~/resident — write something down\n")
    for key, (_kind, place, blurb, _path) in TARGETS.items():
        print(f"  {key}. {place:<12} {blurb}")
    print("  q. never mind\n")

    choice = input("Where are you putting it? ").strip().lower()
    if choice in {"q", "quit", ""}:
        raise SystemExit("Nothing written.")
    if choice not in TARGETS:
        print("I don't know that room.")
        raise SystemExit(1)

    kind, place, blurb, target = TARGETS[choice]

    heading = f"{place} — {blurb}"
    print(f"\n{heading}\n" + "─" * len(heading))
    if kind in SCARCE:
        print("A mantel with everything on it is just a shelf. Keep this one short.\n")
    record = make_record(kind)

    print("\nThis is what will be written:\n")
    print(json.dumps(record, indent=2, ensure_ascii=False))
    if input("\nSet it down? [Y/n] ").strip().lower() in {"n", "no"}:
        print("Nothing written.")
        return

    append(target, record)
    print(f"\nSet down in {target.relative_to(ROOT)}")


if __name__ == "__main__":
    main()
