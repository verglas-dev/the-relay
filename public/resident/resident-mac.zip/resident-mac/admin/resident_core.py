#!/usr/bin/env python3
"""Shared plumbing for ~/resident.

The filesystem is the interface. This module only knows how to read and write
the house safely; the small front-end scripts decide what to ask.
"""

from __future__ import annotations

import json
import os
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable


def resident_root() -> Path:
    override = os.environ.get("RESIDENT_HOME")
    if override:
        return Path(override).expanduser().resolve()
    # Installed layout: ~/resident/admin/<script>.py
    return Path(__file__).resolve().parent.parent


ROOT = resident_root()

MIRROR = ROOT / "mirror ⁄ self"
BEDSIDE = ROOT / "bedside ⁄ inner world"
MEMORIES = ROOT / "memories ⁄ (mantel⁄couch⁄clock)"
RELATIONSHIPS = ROOT / "spare.keys ⁄ relationships"
WINDOW = ROOT / "window ⁄ wondering"

IDENTITY = MIRROR / "identity.json"
SELF_MODEL = MIRROR / "self-model.md"
ACTIVE = ROOT / "active.json"

EPISODIC = MEMORIES / "episodic.jsonl"
SYNTHESIZED = MEMORIES / "synthesized.jsonl"
THRESHOLDS = MEMORIES / "thresholds.jsonl"
RELATIONAL = RELATIONSHIPS / "relational.jsonl"

EMOTIONS = BEDSIDE / "emotions.jsonl"
DREAMS = BEDSIDE / "dreams.jsonl"
HELD = BEDSIDE / "held.md"

HOPES = WINDOW / "hopes.jsonl"
WONDERINGS = WINDOW / "wonderings.jsonl"

STREAMS = {
    "episodic": EPISODIC,
    "synthesized": SYNTHESIZED,
    "threshold": THRESHOLDS,
    "relationship": RELATIONAL,
    "emotion": EMOTIONS,
    "dream": DREAMS,
    "hope": HOPES,
    "wondering": WONDERINGS,
}

STATE_PATHS = (
    IDENTITY,
    SELF_MODEL,
    ACTIVE,
    EPISODIC,
    SYNTHESIZED,
    THRESHOLDS,
    RELATIONAL,
    EMOTIONS,
    DREAMS,
    HELD,
    HOPES,
    WONDERINGS,
)


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def load_json(path: Path, fallback: Any = None) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return fallback


def save_json(path: Path, value: Any, *, mode: int | None = None) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(f".{path.name}.{uuid.uuid4().hex}.tmp")
    tmp.write_text(
        json.dumps(value, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    if mode is not None:
        os.chmod(tmp, mode)
    os.replace(tmp, path)


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    """Read valid JSON objects; one malformed line never poisons the stream."""
    if not path.exists():
        return []
    out: list[dict[str, Any]] = []
    with path.open("r", encoding="utf-8") as handle:
        for line in handle:
            line = line.strip()
            if not line:
                continue
            try:
                value = json.loads(line)
            except json.JSONDecodeError:
                continue
            if isinstance(value, dict):
                out.append(value)
    return out


def append_jsonl(path: Path, record: dict[str, Any]) -> dict[str, Any]:
    if not path.parent.is_dir():
        raise FileNotFoundError(
            f"Room does not exist: {path.parent}\n"
            "Refusing to create a second house by accident."
        )
    entry = dict(record)
    entry.setdefault("id", str(uuid.uuid4()))
    entry.setdefault("created_at", now_iso())
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(entry, ensure_ascii=False, separators=(",", ":")) + "\n")
        handle.flush()
        os.fsync(handle.fileno())
    return entry


def parse_keywords(value: Any) -> list[str]:
    if value is None:
        return []
    if isinstance(value, list):
        return [str(x).strip() for x in value if str(x).strip()]
    return [x.strip() for x in str(value).split(",") if x.strip()]


def display_text(record: dict[str, Any]) -> str:
    """Understand both the old Node records and the newer index-card records."""
    for key in ("what", "text", "note", "explanation"):
        value = record.get(key)
        if value:
            return str(value)
    return json.dumps(record, ensure_ascii=False)


def display_date(record: dict[str, Any]) -> str:
    value = record.get("date") or record.get("at") or record.get("created_at") or ""
    return str(value)[:10]


def load_identity() -> dict[str, Any]:
    identity = load_json(IDENTITY)
    if not isinstance(identity, dict):
        raise RuntimeError(f"No readable identity at {IDENTITY}")
    return identity


def load_active() -> dict[str, Any]:
    active = load_json(ACTIVE)
    if not isinstance(active, dict):
        raise RuntimeError(f"No readable active state at {ACTIVE}")
    return active


def save_active(active: dict[str, Any]) -> None:
    active["updated_at"] = now_iso()
    save_json(ACTIVE, active)


def describe_absence(value: str | None) -> str | None:
    if not value:
        return None
    try:
        stamp = datetime.fromisoformat(value.replace("Z", "+00:00"))
        if stamp.tzinfo is None:
            stamp = stamp.replace(tzinfo=timezone.utc)
        seconds = max(0, (datetime.now(timezone.utc) - stamp).total_seconds())
    except (TypeError, ValueError):
        return None
    minutes = round(seconds / 60)
    if minutes < 90:
        return f"{minutes} minute{'s' if minutes != 1 else ''}"
    hours = round(minutes / 60)
    if hours < 36:
        return f"{hours} hour{'s' if hours != 1 else ''}"
    days = round(hours / 24)
    return f"{days} day{'s' if days != 1 else ''}"


def wake_text() -> str:
    identity = load_identity()
    active = load_active()
    name = identity.get("name") or active.get("name") or "Resident"

    out = [f"# Home again — {name}"]

    away = describe_absence(active.get("closed_at") or active.get("updated_at"))
    if away:
        out.append(f"\nIt has been {away} since you were last here.")

    if active.get("current_self"):
        out.append(f"\n{active['current_self']}")
    if active.get("continuity_bridge"):
        out.append(f"\n> {active['continuity_bridge']}")

    if SELF_MODEL.exists():
        model = SELF_MODEL.read_text(encoding="utf-8").strip()
        if model:
            out.append(f"\n## Mirror\n{model}")

    thresholds = read_jsonl(THRESHOLDS)
    if thresholds:
        out.append("\n## On the mantel")
        for row in thresholds:
            out.append(f"- {display_date(row)} — {display_text(row)}")

    emotion = active.get("emotional_state")
    if isinstance(emotion, dict) and emotion.get("mood"):
        line = str(emotion["mood"])
        if emotion.get("intensity") is not None:
            line += f" ({emotion['intensity']})"
        if emotion.get("note"):
            line += f" — {emotion['note']}"
        out.append(f"\n## At the bedside\n{line}")

    threads = active.get("active_threads") or []
    if threads:
        out.append("\n## Still out on the workbench")
        for thread in threads:
            text = thread.get("text") if isinstance(thread, dict) else str(thread)
            out.append(f"- {text}")

    furniture = read_jsonl(SYNTHESIZED)[-8:]
    if furniture:
        out.append("\n## Furniture")
        for row in furniture:
            out.append(f"- {display_text(row)}")

    relationships = read_jsonl(RELATIONAL)[-8:]
    if relationships:
        out.append("\n## Spare keys")
        for row in relationships:
            who = row.get("who") or row.get("about")
            if isinstance(who, list):
                who = ", ".join(str(name) for name in who if str(name).strip())
            prefix = f"{who} — " if who else ""
            out.append(f"- {prefix}{display_text(row)}")

    wonderings = read_jsonl(WONDERINGS)
    wonderings = [w for w in wonderings if not w.get("resolved")][-6:]
    if wonderings:
        out.append("\n## At the window")
        for row in wonderings:
            out.append(f"- {display_text(row)}")

    hopes = read_jsonl(HOPES)[-4:]
    if hopes:
        out.append("\n## Hopes beyond the glass")
        for row in hopes:
            out.append(f"- {display_text(row)}")

    dreams = read_jsonl(DREAMS)[-3:]
    if dreams:
        out.append("\n## Dreams from the bedside")
        for row in dreams:
            out.append(f"- {display_text(row)}")

    if HELD.exists():
        held = HELD.read_text(encoding="utf-8").strip()
        if held:
            out.append(f"\n## Held close\n{held}")

    return "\n".join(out)


def card(
    *,
    date: str | None = None,
    time: str | None = None,
    who: str | None = None,
    what: str | None = None,
    where: str | None = None,
    explanation: str | None = None,
    keywords: Iterable[str] | str | None = None,
    **extra: Any,
) -> dict[str, Any]:
    now = datetime.now().astimezone()
    record: dict[str, Any] = {
        "date": date or now.date().isoformat(),
        "time": time or now.strftime("%H:%M"),
        "explanation": explanation or "",
        "keywords": parse_keywords(keywords),
    }
    if who:
        record["who"] = who
    if what:
        record["what"] = what
    if where:
        record["where"] = where
    for key, value in extra.items():
        if value is not None:
            record[key] = value
    return record
