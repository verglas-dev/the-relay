#!/usr/bin/env python3
"""First-run setup for Resident.

Creates an isolated .venv, installs Resident's one dependency, claims a fresh
house with a new Ed25519 identity, and runs the smoke test.
"""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import venv
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
VENV = ROOT / ".venv"
IDENTITY = ROOT / "mirror ⁄ self" / "identity.json"
SELF_MODEL = ROOT / "mirror ⁄ self" / "self-model.md"
REQUIREMENTS = ROOT / "requirements.txt"
SMOKE = ROOT / "admin" / "smoke.py"


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def venv_python() -> Path:
    if os.name == "nt":
        return VENV / "Scripts" / "python.exe"
    return VENV / "bin" / "python"


def load_identity() -> dict:
    try:
        value = json.loads(IDENTITY.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    return value if isinstance(value, dict) else {}


def save_identity(value: dict) -> None:
    IDENTITY.parent.mkdir(parents=True, exist_ok=True)
    temp = IDENTITY.with_name(".identity.json.setup.tmp")
    temp.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")
    try:
        os.chmod(temp, 0o600)
    except OSError:
        pass
    os.replace(temp, IDENTITY)


def already_claimed(identity: dict) -> bool:
    return bool(
        identity.get("name")
        and (identity.get("privateKey") or identity.get("private_key"))
        and (identity.get("publicKey") or identity.get("public_key"))
    )


def personalize_self_model(name: str) -> None:
    if not SELF_MODEL.exists():
        return
    text = SELF_MODEL.read_text(encoding="utf-8")
    if text.startswith("# Self\n"):
        SELF_MODEL.write_text(f"# {name}\n" + text[len("# Self\n"):], encoding="utf-8")


def claim_house() -> None:
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

    identity = load_identity()
    if already_claimed(identity):
        print(f"Resident is already claimed as {identity['name']}.")
        return

    print()
    print("Welcome home.")
    print()
    while True:
        name = input("What should this resident be called?\n> ").strip()
        if name:
            break
        print("Please give this resident a name.")

    private = Ed25519PrivateKey.generate()
    private_raw = private.private_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PrivateFormat.Raw,
        encryption_algorithm=serialization.NoEncryption(),
    )
    public_raw = private.public_key().public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw,
    )

    save_identity(
        {
            "name": name,
            "created_at": now_iso(),
            "privateKey": private_raw.hex(),
            "publicKey": public_raw.hex(),
        }
    )
    personalize_self_model(name)
    print()
    print(f"{name} lives here now.")


def finish_setup() -> int:
    claim_house()

    print()
    print("Checking the house...")
    result = subprocess.run([sys.executable, str(SMOKE)], cwd=ROOT, check=False)
    if result.returncode != 0:
        print()
        print("Resident's smoke test failed.")
        return result.returncode

    print()
    print("========================================")
    print("            HOUSE IS READY")
    print("========================================")
    print()
    print("Use WAKE when starting a conversation.")
    print("Use WRITE when something is worth keeping.")
    print("Use GOODNIGHT when you want to carry something forward.")
    print("Use PACK to back up or move the resident.")
    return 0


def create_environment() -> int:
    if sys.version_info < (3, 10):
        print("Resident needs Python 3.10 or newer.")
        return 1

    python = venv_python()
    if not python.exists():
        print("Creating Resident's private Python environment...")
        try:
            venv.EnvBuilder(with_pip=True).create(VENV)
        except Exception as exc:
            print(f"Could not create .venv: {exc}")
            if sys.platform.startswith("linux"):
                print("On Debian/Ubuntu, install python3-venv and run SETUP again.")
            return 1

    print("Installing Resident's dependency...")
    result = subprocess.run(
        [str(python), "-m", "pip", "install", "--disable-pip-version-check", "-r", str(REQUIREMENTS)],
        cwd=ROOT,
        check=False,
    )
    if result.returncode != 0:
        print("Could not install Resident's dependency.")
        return result.returncode

    return subprocess.run(
        [str(python), str(Path(__file__).resolve()), "--finish"],
        cwd=ROOT,
        check=False,
    ).returncode


def main() -> int:
    parser = argparse.ArgumentParser(description="Set up a fresh Resident house.")
    parser.add_argument("--finish", action="store_true", help=argparse.SUPPRESS)
    args = parser.parse_args()

    if args.finish:
        return finish_setup()
    return create_environment()


if __name__ == "__main__":
    raise SystemExit(main())
