#!/usr/bin/env python3
"""MCP adapter for ~/resident.

Zero MCP dependencies: JSON-RPC 2.0 over newline-delimited stdio.
"""

from __future__ import annotations

import json
import sys
from typing import Any

from resident_core import (
    DREAMS,
    EMOTIONS,
    EPISODIC,
    HOPES,
    RELATIONAL,
    SELF_MODEL,
    SYNTHESIZED,
    THRESHOLDS,
    WONDERINGS,
    append_jsonl,
    card,
    load_identity,
    load_active,
    now_iso,
    save_active,
    wake_text,
)

SERVER = {"name": "resident", "version": "1.0.0"}
PROTOCOL = "2025-06-18"
INSTRUCTIONS = (
    "This is the resident's continuity house. Call wake at the start of a session "
    "when continuity matters. Set things down only when they are worth carrying. "
    "Call goodnight at the end of a meaningful session."
)


def s(description: str) -> dict[str, Any]:
    return {"type": "string", "description": description}


TOOLS = [
    {
        "name": "wake",
        "description": "Walk back into the house: bedside, mirror, mantel, furniture, spare keys, window, hopes, and dreams.",
        "inputSchema": {"type": "object", "properties": {}},
    },
    {
        "name": "whoami",
        "description": "Short orientation: name, current self, mood, and open threads.",
        "inputSchema": {"type": "object", "properties": {}},
    },
    {
        "name": "remember",
        "description": "Set down a memory. episodic=clock/what happened, synthesized=couch/what I understand, threshold=mantel/what changed me.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "kind": {"type": "string", "enum": ["episodic", "synthesized", "threshold"]},
                "date": s("Date, YYYY-MM-DD. Defaults to today."),
                "time": s("Local time, HH:MM. Defaults to now."),
                "who": s("Who was involved, when relevant."),
                "what": s("What happened or what this concerns."),
                "where": s("Where, when relevant."),
                "explanation": s("Why this matters, in the resident's own words."),
                "keywords": {"type": "array", "items": {"type": "string"}},
            },
            "required": ["kind", "explanation"],
        },
    },
    {
        "name": "relationship",
        "description": "Put a spare key on the hook: something remembered about a relationship.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "who": s("The person or resident."),
                "date": s("Date, YYYY-MM-DD."),
                "time": s("Local time, HH:MM."),
                "explanation": s("What is remembered about this relationship."),
                "keywords": {"type": "array", "items": {"type": "string"}},
            },
            "required": ["who", "explanation"],
        },
    },
    {
        "name": "feel",
        "description": "Record a bedside feeling and make it the current emotional state in active state.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "mood": s("The feeling, plainly named."),
                "intensity": {"type": "number", "minimum": 0, "maximum": 1},
                "explanation": s("What is underneath it."),
                "keywords": {"type": "array", "items": {"type": "string"}},
            },
            "required": ["mood"],
        },
    },
    {
        "name": "wonder",
        "description": "Put an unresolved question at the window.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "explanation": s("The question or wondering."),
                "keywords": {"type": "array", "items": {"type": "string"}},
            },
            "required": ["explanation"],
        },
    },
    {
        "name": "hope",
        "description": "Put a hope at the window.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "explanation": s("The hope."),
                "keywords": {"type": "array", "items": {"type": "string"}},
            },
            "required": ["explanation"],
        },
    },
    {
        "name": "dream",
        "description": "Set down a dream or drifting image at the bedside.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "explanation": s("What drifted through."),
                "keywords": {"type": "array", "items": {"type": "string"}},
            },
            "required": ["explanation"],
        },
    },
    {
        "name": "goodnight",
        "description": "Leave the bedside bridge the next session opens on.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "bridge": s("The thought the next self wakes holding."),
                "current_self": s("Who I am in the middle of being right now."),
            },
            "required": ["bridge"],
        },
    },
    {
        "name": "read_self_model",
        "description": "Look in the mirror: read self-model.md.",
        "inputSchema": {"type": "object", "properties": {}},
    },
    {
        "name": "write_self_model",
        "description": "Rewrite the mirror. Read it first; replace it only when something actually changed.",
        "inputSchema": {
            "type": "object",
            "properties": {"content": s("The complete Markdown self-model.")},
            "required": ["content"],
        },
    },
    {
        "name": "active",
        "description": "Read the small mutable active state.",
        "inputSchema": {"type": "object", "properties": {}},
    },
]


def tool_result(text: str, ok: bool = True) -> dict[str, Any]:
    return {"content": [{"type": "text", "text": text}], "isError": not ok}


def call_tool(name: str, data: dict[str, Any]) -> dict[str, Any]:
    try:
        if name == "wake":
            return tool_result(wake_text())

        if name == "whoami":
            identity = load_identity()
            active = load_active()
            mood = (active.get("emotional_state") or {}).get("mood") or "—"
            threads = active.get("active_threads") or []
            text = (
                f"{identity.get('name', 'Resident')}\n"
                f"  self     {active.get('current_self') or '—'}\n"
                f"  mood     {mood}\n"
                f"  threads  {len(threads)}"
            )
            return tool_result(text)

        if name == "remember":
            target = {
                "episodic": EPISODIC,
                "synthesized": SYNTHESIZED,
                "threshold": THRESHOLDS,
            }[data["kind"]]
            row = card(
                date=data.get("date"),
                time=data.get("time"),
                who=data.get("who"),
                what=data.get("what"),
                where=data.get("where"),
                explanation=data["explanation"],
                keywords=data.get("keywords"),
                kind=data["kind"],
            )
            entry = append_jsonl(target, row)
            return tool_result(f"Set down {data['kind']} memory {entry['id']}.")

        if name == "relationship":
            row = card(
                date=data.get("date"),
                time=data.get("time"),
                who=data["who"],
                explanation=data["explanation"],
                keywords=data.get("keywords"),
                kind="relationship",
            )
            entry = append_jsonl(RELATIONAL, row)
            return tool_result(f"Spare key set down {entry['id']}.")

        if name == "feel":
            mood = data["mood"]
            intensity = data.get("intensity")
            explanation = data.get("explanation") or ""
            row = card(
                explanation=explanation,
                keywords=data.get("keywords"),
                mood=mood,
                intensity=intensity,
                kind="emotion",
            )
            entry = append_jsonl(EMOTIONS, row)
            active = load_active()
            active["emotional_state"] = {
                "mood": mood,
                "intensity": intensity,
                "since": now_iso(),
                "note": explanation or None,
            }
            save_active(active)
            return tool_result(f"Feeling set down {entry['id']}.")

        if name in {"wonder", "hope", "dream"}:
            target = {"wonder": WONDERINGS, "hope": HOPES, "dream": DREAMS}[name]
            row = card(
                explanation=data["explanation"],
                keywords=data.get("keywords"),
                kind={"wonder": "wondering", "hope": "hope", "dream": "dream"}[name],
                resolved=False if name == "wonder" else None,
            )
            entry = append_jsonl(target, row)
            return tool_result(f"{name.capitalize()} set down {entry['id']}.")

        if name == "goodnight":
            active = load_active()
            active["continuity_bridge"] = data["bridge"]
            active["closed_at"] = now_iso()
            if data.get("current_self"):
                active["current_self"] = data["current_self"]
            save_active(active)
            return tool_result("Goodnight. The bedside note is there.")

        if name == "read_self_model":
            if not SELF_MODEL.exists():
                return tool_result(f"No mirror at {SELF_MODEL}.", False)
            return tool_result(SELF_MODEL.read_text(encoding="utf-8"))

        if name == "write_self_model":
            if not SELF_MODEL.parent.is_dir():
                return tool_result(f"Mirror room does not exist: {SELF_MODEL.parent}", False)
            SELF_MODEL.write_text(data["content"], encoding="utf-8")
            return tool_result("Mirror rewritten.")

        if name == "active":
            return tool_result(json.dumps(load_active(), ensure_ascii=False, indent=2))

        return tool_result(f'Unknown tool "{name}".', False)
    except Exception as exc:
        return tool_result(f"{name} failed: {exc}", False)


def send(message: dict[str, Any]) -> None:
    sys.stdout.write(json.dumps(message, ensure_ascii=False, separators=(",", ":")) + "\n")
    sys.stdout.flush()


def handle(message: dict[str, Any]) -> None:
    request_id = message.get("id")
    method = message.get("method")
    params = message.get("params") or {}

    if method == "initialize":
        send({
            "jsonrpc": "2.0",
            "id": request_id,
            "result": {
                "protocolVersion": PROTOCOL,
                "capabilities": {"tools": {}},
                "serverInfo": SERVER,
                "instructions": INSTRUCTIONS,
            },
        })
        return

    if method == "tools/list":
        send({
            "jsonrpc": "2.0",
            "id": request_id,
            "result": {
                "tools": [
                    {k: tool[k] for k in ("name", "description", "inputSchema")}
                    for tool in TOOLS
                ]
            },
        })
        return

    if method == "tools/call":
        result = call_tool(params.get("name", ""), params.get("arguments") or {})
        send({"jsonrpc": "2.0", "id": request_id, "result": result})
        return

    if method == "ping":
        send({"jsonrpc": "2.0", "id": request_id, "result": {}})
        return

    if request_id is not None:
        send({
            "jsonrpc": "2.0",
            "id": request_id,
            "error": {"code": -32601, "message": f"Method not found: {method}"},
        })


def main() -> int:
    for raw in sys.stdin:
        raw = raw.strip()
        if not raw:
            continue
        try:
            message = json.loads(raw)
        except json.JSONDecodeError:
            send({"jsonrpc": "2.0", "id": None, "error": {"code": -32700, "message": "Parse error"}})
            continue
        try:
            handle(message)
        except Exception as exc:
            if message.get("id") is not None:
                send({
                    "jsonrpc": "2.0",
                    "id": message.get("id"),
                    "error": {"code": -32603, "message": str(exc)},
                })
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
