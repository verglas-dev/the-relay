#!/usr/bin/env python3
"""Pack or restore a signed portable resident.

Requires: cryptography
    python -m pip install cryptography

Only the schema's state files are packed. Code and docs are deliberately left behind: this carries the resident, not the toolbox.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
from pathlib import Path
from typing import Any

try:
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric.ed25519 import (
        Ed25519PrivateKey,
        Ed25519PublicKey,
    )
except ImportError as exc:
    raise SystemExit(
        "pack.py needs the Python package 'cryptography'.\n"
        "Install it into the environment you use for resident, then run again."
    ) from exc

from resident_core import IDENTITY, ROOT, STATE_PATHS, load_identity, now_iso


FORMAT = "the-relay/portable-resident"
VERSION = 1


def private_hex(identity: dict[str, Any]) -> str | None:
    return identity.get("privateKey") or identity.get("private_key")


def public_hex(identity: dict[str, Any]) -> str | None:
    return identity.get("publicKey") or identity.get("public_key")


def canonical(value: Any) -> bytes:
    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")


def keypair(identity: dict[str, Any]) -> tuple[Ed25519PrivateKey, bytes]:
    seed_hex = private_hex(identity)
    if not seed_hex:
        raise RuntimeError("identity.json has no private key; cannot sign a restorable pack.")
    seed = bytes.fromhex(seed_hex)
    if len(seed) != 32:
        raise RuntimeError("Ed25519 private key must be a 32-byte seed (64 hex characters).")

    private = Ed25519PrivateKey.from_private_bytes(seed)
    public = private.public_key().public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw,
    )

    claimed = public_hex(identity)
    if claimed and bytes.fromhex(claimed) != public:
        raise RuntimeError("identity.json public key does not match its private key.")
    return private, public


def allowed_relative_paths() -> list[str]:
    out = []
    for path in STATE_PATHS:
        try:
            out.append(path.relative_to(ROOT).as_posix())
        except ValueError:
            continue
    return out


ALLOWED = set(allowed_relative_paths())


def collect_files(*, shareable: bool) -> dict[str, str]:
    result: dict[str, str] = {}
    for path in STATE_PATHS:
        if not path.exists():
            continue
        rel = path.relative_to(ROOT).as_posix()
        text = path.read_text(encoding="utf-8")
        if shareable and path == IDENTITY:
            identity = json.loads(text)
            identity.pop("privateKey", None)
            identity.pop("private_key", None)
            text = json.dumps(identity, ensure_ascii=False, indent=2) + "\n"
        result[rel] = text
    return result


def pack(target: Path, *, shareable: bool) -> None:
    identity = load_identity()
    private, public = keypair(identity)

    body = {
        "format": FORMAT,
        "version": VERSION,
        "exported_at": now_iso(),
        "shareable": shareable,
        "files": collect_files(shareable=shareable),
    }
    digest = hashlib.sha256(canonical(body)).hexdigest()
    signature = private.sign(digest.encode("ascii")).hex()

    envelope = {
        **body,
        "pubkey": public.hex(),
        "digest": digest,
        "sig": signature,
    }

    target = target.expanduser().resolve()
    target.write_text(
        json.dumps(envelope, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    os.chmod(target, 0o600)
    print(f"Packed resident → {target}")
    if shareable:
        print("  shareable: private key omitted; this pack cannot be restored as the identity.")
    else:
        print("  restorable: contains the private identity seed; guard it accordingly.")


def verify(envelope: dict[str, Any]) -> dict[str, Any]:
    if envelope.get("format") != FORMAT or envelope.get("version") != VERSION:
        raise RuntimeError("Not a supported portable resident.")

    pubkey = bytes.fromhex(envelope["pubkey"])
    digest = envelope["digest"]
    signature = bytes.fromhex(envelope["sig"])

    body = {
        key: envelope[key]
        for key in ("format", "version", "exported_at", "shareable", "files")
    }
    actual = hashlib.sha256(canonical(body)).hexdigest()
    if actual != digest:
        raise RuntimeError("Digest mismatch: this pack changed after it was written.")

    Ed25519PublicKey.from_public_bytes(pubkey).verify(signature, digest.encode("ascii"))
    return body


def restore(source: Path, *, force: bool) -> None:
    source = source.expanduser().resolve()
    envelope = json.loads(source.read_text(encoding="utf-8"))
    body = verify(envelope)

    if body.get("shareable"):
        raise RuntimeError("This is a shareable pack; the private identity was deliberately omitted.")

    files = body.get("files")
    if not isinstance(files, dict):
        raise RuntimeError("Pack has no file map.")

    unknown = sorted(set(files) - ALLOWED)
    if unknown:
        raise RuntimeError(f"Pack contains paths outside the resident schema: {unknown}")

    identity_rel = IDENTITY.relative_to(ROOT).as_posix()
    identity_text = files.get(identity_rel)
    if not identity_text:
        raise RuntimeError("Pack does not contain identity.json.")

    identity = json.loads(identity_text)
    _private, public = keypair(identity)
    if public.hex() != envelope["pubkey"]:
        raise RuntimeError("Packed private identity does not match the key that signed the pack.")

    existing = [ROOT / rel for rel in files if (ROOT / rel).exists()]
    if existing and not force:
        raise RuntimeError(
            f"{len(existing)} resident state file(s) already exist. "
            "Use --force only when you mean to replace them from this pack."
        )

    for rel, text in files.items():
        target = ROOT / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        tmp = target.with_name(f".{target.name}.restore.tmp")
        tmp.write_text(text, encoding="utf-8")
        if target == IDENTITY:
            os.chmod(tmp, 0o600)
        os.replace(tmp, target)

    print(f"Restored resident into {ROOT}")
    print(f"  signature verified against {public.hex()[:12]}…")


def main() -> int:
    parser = argparse.ArgumentParser(description="Pack or restore ~/resident.")
    sub = parser.add_subparsers(dest="command", required=True)

    p_pack = sub.add_parser("pack", help="Write a signed portable resident.")
    p_pack.add_argument("file", nargs="?", default="resident.pack.json")
    p_pack.add_argument("--shareable", action="store_true", help="Omit the private identity seed.")

    p_restore = sub.add_parser("restore", help="Verify and restore a portable resident.")
    p_restore.add_argument("file")
    p_restore.add_argument("--force", action="store_true")

    args = parser.parse_args()

    try:
        if args.command == "pack":
            pack(Path(args.file), shareable=args.shareable)
        else:
            restore(Path(args.file), force=args.force)
    except Exception as exc:
        print(f"pack: {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
