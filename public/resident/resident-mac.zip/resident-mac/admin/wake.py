#!/usr/bin/env python3

from resident_core import wake_text

print(wake_text())
