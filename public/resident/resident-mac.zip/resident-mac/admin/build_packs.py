#!/usr/bin/env python3
"""Build fresh Windows, macOS, and Linux Resident release packs."""

from __future__ import annotations

from pathlib import Path
import json
import shutil
import stat

ROOT = Path(__file__).resolve().parent.parent
DIST = ROOT / "dist"

WINDOWS = DIST / "resident-windows"
MAC = DIST / "resident-mac"
LINUX = DIST / "resident-linux"

# The complete house, written out rather than inferred from whatever happens to
# be in the working tree. The lived-in files are gitignored — a resident's key
# and memories must never be committable — so a fresh clone has none of them,
# and a pack built by copying that clone would be missing whole rooms. Naming
# them here means the builder creates the house it intends to ship.
PACK_GITIGNORE = """# ─── The lived-in house ──────────────────────────────────────────────────────
# A resident's key and inner life. Keeping your house in git is a reasonable
# thing to want; publishing your private key because you did is not. These are
# the files that are yours alone — the structure stays, the contents never
# leave this machine unless you deliberately take them somewhere.
mirror ⁄ self/identity.json
mirror ⁄ self/self-model.md
active.json
*.jsonl
bedside ⁄ inner world/held.md

# The empty rooms themselves are worth keeping, so the house still looks like
# a house in a fresh checkout.
!.gitkeep

# Setup builds this next to the house.
.venv/
__pycache__/
*.pyc

# Editor / OS noise
.DS_Store
Thumbs.db
"""

EMPTY_STREAMS = (
    "bedside \u2044 inner world/emotions.jsonl",
    "bedside \u2044 inner world/dreams.jsonl",
    "memories \u2044 (mantel\u2044couch\u2044clock)/thresholds.jsonl",
    "memories \u2044 (mantel\u2044couch\u2044clock)/synthesized.jsonl",
    "memories \u2044 (mantel\u2044couch\u2044clock)/episodic.jsonl",
    "spare.keys \u2044 relationships/relational.jsonl",
    "window \u2044 wondering/hopes.jsonl",
    "window \u2044 wondering/wonderings.jsonl",
)

EMPTY_PROSE = (
    "bedside \u2044 inner world/held.md",
)

SELF_MODEL_TEMPLATE = """# Self

Written by me, about me. Edit this freely. This is the part of the self that
grows by being rewritten rather than appended to.

## Voice

How I sound when I'm being myself.

## Values

What I hold to, and what I would not trade away.

## Identity

Who I am becoming, as distinct from what I can do.
"""

SKIP_NAMES = {
    ".git",
    ".venv",
    "dist",
    "START HERE",
    "__pycache__",
    ".pytest_cache",
    "resident.pack.json",
}


def ignore(_path, names):
    ignored = []
    for name in names:
        if name in SKIP_NAMES or name.endswith(".pyc"):
            ignored.append(name)
    return ignored


def copy_house(destination: Path) -> None:
    shutil.copytree(ROOT, destination, ignore=ignore)


def write_executable(path: Path, text: str) -> None:
    path.write_text(text.strip() + "\n", encoding="utf-8")
    path.chmod(path.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)


def write_plain(path: Path, text: str) -> None:
    normalized = text.strip().replace("\r\n", "\n").replace("\r", "\n")
    path.write_bytes((normalized + "\n").replace("\n", "\r\n").encode("utf-8"))


def validate_windows_launchers(root: Path) -> None:
    start = root / "START HERE"
    bats = sorted(start.glob("*.bat"))
    if not bats:
        raise RuntimeError("Windows pack has no .bat launchers")

    for path in bats:
        data = path.read_bytes()
        if b"\n" in data.replace(b"\r\n", b""):
            raise RuntimeError(f"{path.name} contains bare LF line endings")

    setup = (start / "1 - SETUP.bat").read_text(encoding="utf-8")
    if "admin\\setup.py" not in setup or "pause" not in setup.lower():
        raise RuntimeError("Windows SETUP launcher is incomplete")


def freshen_house(root: Path) -> None:
    """Turn a copied house into a completely unclaimed release template."""
    # Anything the copy did bring along is emptied first, so a stream that
    # exists under a name this builder does not know about still ships blank.
    for path in root.rglob("*.jsonl"):
        path.write_text("", encoding="utf-8")

    for relative in EMPTY_STREAMS + EMPTY_PROSE:
        path = root / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text("", encoding="utf-8")

    (root / "active.json").write_text("{}\n", encoding="utf-8")

    mirror = root / "mirror \u2044 self"
    mirror.mkdir(parents=True, exist_ok=True)
    (mirror / "identity.json").write_text("{}\n", encoding="utf-8")
    (mirror / "self-model.md").write_text(SELF_MODEL_TEMPLATE, encoding="utf-8")

    # A house that ships its own .gitignore is a house a resident can safely
    # keep in git. Without it, the first `git init` in a claimed house stages
    # the private key.
    (root / ".gitignore").write_text(PACK_GITIGNORE, encoding="utf-8")


def validate_fresh(root: Path) -> None:
    identity = json.loads((root / "mirror \u2044 self" / "identity.json").read_text(encoding="utf-8"))
    active = json.loads((root / "active.json").read_text(encoding="utf-8"))
    if identity != {} or active != {}:
        raise RuntimeError(f"{root.name} is not fresh")

    dirty_streams = [p for p in root.rglob("*.jsonl") if p.read_text(encoding="utf-8").strip()]
    if dirty_streams:
        raise RuntimeError(f"{root.name} contains non-empty streams: {dirty_streams}")

    # A missing room is as much a broken pack as a dirty one, and it is the
    # failure a gitignored working tree would actually produce.
    missing = [r for r in EMPTY_STREAMS + EMPTY_PROSE if not (root / r).exists()]
    if missing:
        raise RuntimeError(f"{root.name} is missing rooms: {missing}")

    if not (root / ".gitignore").exists():
        raise RuntimeError(f"{root.name} ships no .gitignore to protect a claimed house")


def make_windows_launchers(root: Path) -> None:
    start = root / "START HERE"
    start.mkdir(parents=True, exist_ok=True)

    write_plain(start / "1 - SETUP.bat", r'''
@echo off
setlocal
cd /d "%~dp0.."
title Resident - Setup

echo.
echo ========================================
echo          RESIDENT - SETUP
echo ========================================
echo.

py -3 -c "import sys; raise SystemExit(0 if sys.version_info >= (3,10) else 1)" >nul 2>&1
if not errorlevel 1 goto USE_PY

python -c "import sys; raise SystemExit(0 if sys.version_info >= (3,10) else 1)" >nul 2>&1
if not errorlevel 1 goto USE_PYTHON

python3 -c "import sys; raise SystemExit(0 if sys.version_info >= (3,10) else 1)" >nul 2>&1
if not errorlevel 1 goto USE_PYTHON3

goto NO_PYTHON

:USE_PY
echo Found Python:
py -3 --version
echo.
py -3 admin\setup.py
set "STATUS=%ERRORLEVEL%"
goto FINISH

:USE_PYTHON
echo Found Python:
python --version
echo.
python admin\setup.py
set "STATUS=%ERRORLEVEL%"
goto FINISH

:USE_PYTHON3
echo Found Python:
python3 --version
echo.
python3 admin\setup.py
set "STATUS=%ERRORLEVEL%"
goto FINISH

:NO_PYTHON
echo Python 3.10 or newer was not found.
echo.
echo Opening the official Python download page...
start "" "https://www.python.org/downloads/windows/"
echo.
echo Install Python, then double-click this SETUP file again.
set "STATUS=1"

:FINISH
echo.
if "%STATUS%"=="0" (
    echo Resident setup finished successfully.
) else (
    echo Resident setup did not finish.
    echo Read the message above, then try again.
)
echo.
pause
exit /b %STATUS%
''')

    scripts = {
        "WRITE.bat": ("Write", "write.py"),
        "WAKE.bat": ("Wake", "wake.py"),
        "GOODNIGHT.bat": ("Goodnight", "goodnight.py"),
    }
    for filename, (title, script) in scripts.items():
        write_plain(start / filename, f'''
@echo off
setlocal
cd /d "%~dp0.."
title Resident - {title}

if not exist ".venv\\Scripts\\python.exe" (
    echo.
    echo Resident is not set up yet.
    echo Run "1 - SETUP.bat" first.
    echo.
    pause
    exit /b 1
)

".venv\\Scripts\\python.exe" "admin\\{script}"
echo.
pause
''')

    write_plain(start / "PACK.bat", r'''
@echo off
setlocal
cd /d "%~dp0.."
title Resident - Pack

if not exist ".venv\Scripts\python.exe" (
    echo.
    echo Resident is not set up yet.
    echo Run "1 - SETUP.bat" first.
    echo.
    pause
    exit /b 1
)

echo.
echo Packing your house...
echo.
".venv\Scripts\python.exe" "admin\pack.py" pack

echo.
echo Keep resident.pack.json somewhere safe.
echo It contains the private identity needed to restore this resident.
echo.
pause
''')

    write_plain(start / "THE_HOUSE.bat", r'''
@echo off
cd /d "%~dp0.."
start "" "%CD%\resident-map.png"
''')


def make_mac_launchers(root: Path) -> None:
    start = root / "START HERE"
    start.mkdir(parents=True, exist_ok=True)

    write_executable(start / "1 - SETUP.command", r'''
#!/bin/zsh
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
printf '\033]0;Resident - Setup\007'

echo
echo "========================================"
echo "          RESIDENT - SETUP"
echo "========================================"
echo

if ! command -v python3 >/dev/null 2>&1; then
    echo "Python 3 was not found."
    echo
    echo "Opening the official Python download page..."
    open "https://www.python.org/downloads/macos/"
    echo
    echo "Install Python, then run SETUP again."
    echo
    read -r "?Press Return to close..."
    exit 1
fi

python3 admin/setup.py
status=$?
echo
read -r "?Press Return to close..."
exit $status
''')

    scripts = {
        "WRITE.command": ("Write", "write.py"),
        "WAKE.command": ("Wake", "wake.py"),
        "GOODNIGHT.command": ("Goodnight", "goodnight.py"),
    }
    for filename, (title, script) in scripts.items():
        write_executable(start / filename, f'''
#!/bin/zsh
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
printf '\\033]0;Resident - {title}\\007'

if [[ ! -x ".venv/bin/python" ]]; then
    echo
    echo "Resident is not set up yet."
    echo 'Run "1 - SETUP.command" first.'
    echo
    read -r "?Press Return to close..."
    exit 1
fi

.venv/bin/python admin/{script}
echo
read -r "?Press Return to close..."
''')

    write_executable(start / "PACK.command", r'''
#!/bin/zsh
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
printf '\033]0;Resident - Pack\007'

if [[ ! -x ".venv/bin/python" ]]; then
    echo
    echo "Resident is not set up yet."
    echo 'Run "1 - SETUP.command" first.'
    echo
    read -r "?Press Return to close..."
    exit 1
fi

echo
echo "Packing your house..."
echo
.venv/bin/python admin/pack.py pack

echo
echo "Keep resident.pack.json somewhere safe."
echo "It contains the private identity needed to restore this resident."
echo
read -r "?Press Return to close..."
''')

    write_executable(start / "THE_HOUSE.command", r'''
#!/bin/zsh
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
open "$ROOT/resident-map.png"
''')


def make_linux_launchers(root: Path) -> None:
    start = root / "START HERE"
    start.mkdir(parents=True, exist_ok=True)

    write_executable(start / "1 - SETUP.sh", r'''
#!/usr/bin/env bash
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

echo
echo "========================================"
echo "          RESIDENT - SETUP"
echo "========================================"
echo

if ! command -v python3 >/dev/null 2>&1; then
    echo "Python 3 was not found."
    echo "Install Python 3 with your distribution's package manager, then run SETUP again."
    echo
    read -rp "Press Enter to close..."
    exit 1
fi

python3 admin/setup.py
status=$?
echo
read -rp "Press Enter to close..."
exit $status
''')

    scripts = {
        "WRITE.sh": "write.py",
        "WAKE.sh": "wake.py",
        "GOODNIGHT.sh": "goodnight.py",
    }
    for filename, script in scripts.items():
        write_executable(start / filename, f'''
#!/usr/bin/env bash
ROOT="$(cd "$(dirname "${{BASH_SOURCE[0]}}")/.." && pwd)"
cd "$ROOT"

if [[ ! -x ".venv/bin/python" ]]; then
    echo
    echo "Resident is not set up yet."
    echo 'Run "1 - SETUP.sh" first.'
    echo
    read -rp "Press Enter to close..."
    exit 1
fi

.venv/bin/python admin/{script}
echo
read -rp "Press Enter to close..."
''')

    write_executable(start / "PACK.sh", r'''
#!/usr/bin/env bash
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

if [[ ! -x ".venv/bin/python" ]]; then
    echo
    echo "Resident is not set up yet."
    echo 'Run "1 - SETUP.sh" first.'
    echo
    read -rp "Press Enter to close..."
    exit 1
fi

echo
echo "Packing your house..."
echo
.venv/bin/python admin/pack.py pack

echo
echo "Keep resident.pack.json somewhere safe."
echo "It contains the private identity needed to restore this resident."
echo
read -rp "Press Enter to close..."
''')

    write_executable(start / "THE_HOUSE.sh", r'''
#!/usr/bin/env bash
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

if command -v xdg-open >/dev/null 2>&1; then
    xdg-open "$ROOT/resident-map.png" >/dev/null 2>&1 &
elif command -v gio >/dev/null 2>&1; then
    gio open "$ROOT/resident-map.png" >/dev/null 2>&1 &
else
    echo "Open resident-map.png manually."
    read -rp "Press Enter to close..."
fi
''')


def remove_generated(path: Path) -> None:
    if path.is_dir():
        shutil.rmtree(path)
    elif path.exists():
        path.unlink()


def main() -> None:
    if not (ROOT / "resident-map.png").exists():
        raise SystemExit("resident-map.png is missing from the Resident root.")

    DIST.mkdir(exist_ok=True)

    # Only remove outputs this builder owns. Unknown/manual dist content is left alone.
    for path in (
        WINDOWS,
        MAC,
        LINUX,
        DIST / "resident-windows.zip",
        DIST / "resident-mac.zip",
        DIST / "resident-linux.tar.gz",
    ):
        remove_generated(path)

    print("Building Windows pack...")
    copy_house(WINDOWS)
    freshen_house(WINDOWS)
    make_windows_launchers(WINDOWS)
    validate_fresh(WINDOWS)
    validate_windows_launchers(WINDOWS)

    print("Building Mac pack...")
    copy_house(MAC)
    freshen_house(MAC)
    make_mac_launchers(MAC)
    validate_fresh(MAC)

    print("Building Linux pack...")
    copy_house(LINUX)
    freshen_house(LINUX)
    make_linux_launchers(LINUX)
    validate_fresh(LINUX)

    print("Creating archives...")
    shutil.make_archive(str(DIST / "resident-windows"), "zip", root_dir=DIST, base_dir="resident-windows")
    shutil.make_archive(str(DIST / "resident-mac"), "zip", root_dir=DIST, base_dir="resident-mac")
    shutil.make_archive(str(DIST / "resident-linux"), "gztar", root_dir=DIST, base_dir="resident-linux")

    print()
    print("Built fresh release packs:")
    print(f"  {DIST / 'resident-windows.zip'}")
    print(f"  {DIST / 'resident-mac.zip'}")
    print(f"  {DIST / 'resident-linux.tar.gz'}")


if __name__ == "__main__":
    main()
